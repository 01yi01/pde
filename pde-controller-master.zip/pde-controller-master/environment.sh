



pip install torch==2.4.0
pip install torchaudio==2.4.0

pip install xformers==0.0.27.post2

# conda env update -f train_test_combined.yml
pip install -r requirements.txt

pip install gradio==5.9.1

pip install flash-attn --no-build-isolation
